/* global chrome */

// Content script for JWT synchronization between website and extension
console.log('🔄 SabApplier Extension: Content script loaded on', window.location.hostname);

// Listen for JWT tokens from the website
window.addEventListener('message', function(event) {
  console.log('🔄 SabApplier Extension: Message received from website:', event.data);
  
  // Only accept messages from the same origin
  if (event.origin !== window.location.origin) {
    console.log('❌ SabApplier Extension: Rejected message from different origin:', event.origin);
    return;
  }

  // Check if the message is a JWT token from our website
  if (event.data && event.data.type === 'SABAPPLIER_JWT_TOKEN') {
    console.log('✅ SabApplier Extension: JWT token received from website');
    
    // Send the token to the background script
    chrome.runtime.sendMessage({
      action: 'JWT_TOKEN_RECEIVED',
      token: event.data.token,
      userData: event.data.userData,
      timestamp: Date.now()
    }).then(response => {
      console.log('✅ SabApplier Extension: Token sent to background script, response:', response);
    }).catch(error => {
      console.error('❌ SabApplier Extension: Error sending JWT token to background:', error);
    });
  }
  
  // Check if the message is a logout from our website
  if (event.data && event.data.type === 'SABAPPLIER_LOGOUT') {
    console.log('✅ SabApplier Extension: Logout message received from website');
    
    // Send logout notification to the background script
    chrome.runtime.sendMessage({
      action: 'JWT_TOKEN_CLEARED',
      reason: 'website_logout',
      timestamp: Date.now()
    }).then(response => {
      console.log('✅ SabApplier Extension: Website logout sent to background script, response:', response);
    }).catch(error => {
      console.error('❌ SabApplier Extension: Error sending website logout to background:', error);
    });
  }
});

// Listen for custom events from the website
window.addEventListener('sabapplier_jwt_login', function(event) {
  console.log('🔄 SabApplier Extension: Custom JWT login event received:', event.detail);
  
  // Send the token to the background script
  chrome.runtime.sendMessage({
    action: 'JWT_TOKEN_RECEIVED',
    token: event.detail.token,
    userData: event.detail.userData,
    timestamp: Date.now(),
    source: 'custom_event'
  }).then(response => {
    console.log('✅ SabApplier Extension: Custom event token sent to background script, response:', response);
  }).catch(error => {
    console.error('❌ SabApplier Extension: Error sending custom event JWT token to background:', error);
  });
});

// Listen for logout events
window.addEventListener('sabapplier_jwt_logout', function(event) {
  console.log('🔄 SabApplier Extension: JWT logout event received');
  
  chrome.runtime.sendMessage({
    action: 'JWT_TOKEN_CLEARED',
    reason: 'logout_event',
    timestamp: Date.now()
  }).then(response => {
    console.log('✅ SabApplier Extension: Logout sent to background script, response:', response);
  }).catch(error => {
    console.error('❌ SabApplier Extension: Error sending JWT logout to background:', error);
  });
});

// Listen for extension-specific logout events
window.addEventListener('sabapplier_extension_logout', function(event) {
  console.log('🔄 SabApplier Extension: Extension-specific logout event received');
  
  chrome.runtime.sendMessage({
    action: 'JWT_TOKEN_CLEARED',
    reason: 'extension_logout_event',
    timestamp: Date.now()
  }).then(response => {
    console.log('✅ SabApplier Extension: Extension logout sent to background script, response:', response);
  }).catch(error => {
    console.error('❌ SabApplier Extension: Error sending extension logout to background:', error);
  });
});

// Check for existing JWT tokens in localStorage/sessionStorage
function checkExistingTokens() {
  const localJWT = localStorage.getItem('sabapplier_jwt_token') || localStorage.getItem('jwt_token');
  const sessionJWT = sessionStorage.getItem('sabapplier_jwt_token') || sessionStorage.getItem('jwt_token');
  
  // Check for user data as well
  const userData = localStorage.getItem('sabapplier_user_data') || localStorage.getItem('user_data');
  
  if (localJWT || sessionJWT) {
    console.log('SabApplier Extension: Found existing JWT token');
    
    // Send the token to the background script
    chrome.runtime.sendMessage({
      action: 'JWT_TOKEN_RECEIVED',
      token: localJWT || sessionJWT,
      userData: userData ? JSON.parse(userData) : null,
      timestamp: Date.now(),
      source: 'existing'
    }).catch(error => {
      console.error('Error sending existing JWT token to background:', error);
    });
  }
}

// Check for existing tokens when the content script loads
setTimeout(checkExistingTokens, 1000);

// Monitor localStorage changes
const originalSetItem = localStorage.setItem;
localStorage.setItem = function(key, value) {
  if (key.includes('jwt_token') || key.includes('sabapplier_jwt_token')) {
    console.log('SabApplier Extension: JWT token updated in localStorage');
    
    // Get user data if available
    const userData = localStorage.getItem('sabapplier_user_data') || localStorage.getItem('user_data');
    
    chrome.runtime.sendMessage({
      action: 'JWT_TOKEN_RECEIVED',
      token: value,
      userData: userData ? JSON.parse(userData) : null,
      timestamp: Date.now(),
      source: 'localStorage'
    }).catch(error => {
      console.error('Error sending JWT token update to background:', error);
    });
  }
  
  originalSetItem.apply(this, arguments);
};

// Monitor sessionStorage changes
const originalSessionSetItem = sessionStorage.setItem;
sessionStorage.setItem = function(key, value) {
  if (key.includes('jwt_token') || key.includes('sabapplier_jwt_token')) {
    console.log('SabApplier Extension: JWT token updated in sessionStorage');
    
    // Get user data if available
    const userData = sessionStorage.getItem('sabapplier_user_data') || sessionStorage.getItem('user_data');
    
    chrome.runtime.sendMessage({
      action: 'JWT_TOKEN_RECEIVED',
      token: value,
      userData: userData ? JSON.parse(userData) : null,
      timestamp: Date.now(),
      source: 'sessionStorage'
    }).catch(error => {
      console.error('Error sending JWT token update to background:', error);
    });
  }
  
  originalSessionSetItem.apply(this, arguments);
};

// Listen for logout events
window.addEventListener('beforeunload', function() {
  // Check if tokens are being cleared (logout)
  const localJWT = localStorage.getItem('sabapplier_jwt_token') || localStorage.getItem('jwt_token');
  const sessionJWT = sessionStorage.getItem('sabapplier_jwt_token') || sessionStorage.getItem('jwt_token');
  
  if (!localJWT && !sessionJWT) {
    chrome.runtime.sendMessage({
      action: 'JWT_TOKEN_CLEARED',
      timestamp: Date.now()
    }).catch(error => {
      console.error('Error sending JWT token clear to background:', error);
    });
  }
});

// Inject a script to monitor for custom events from the website
const script = document.createElement('script');
script.textContent = `
  // Monitor for custom JWT events
  window.addEventListener('sabapplier_jwt_login', function(event) {
    window.postMessage({
      type: 'SABAPPLIER_JWT_TOKEN',
      token: event.detail.token,
      userData: event.detail.userData
    }, window.location.origin);
  });
  
  window.addEventListener('sabapplier_jwt_logout', function(event) {
    window.postMessage({
      type: 'SABAPPLIER_JWT_LOGOUT'
    }, window.location.origin);
  });
`;
document.head.appendChild(script);

// =========================
// EXISTING FORM CAPTURE CODE
// =========================

// SabApplier AI Content Script
// Automatically captures form data and sends to extension sidebar

let capturedFormData = [];
let isCapturing = true;
let lastInputTime = null;
let debounceTimer = null;
let autofilledData = []; // Track autofilled data
let originalAutofilledValues = new Map(); // Store original autofilled values
let isAdaptiveLearningEnabled = true;

// Initialize the content script
function initialize() {
    console.log('SabApplier AI: Content script initialized');
    
    // Start capturing form data automatically
    startFormCapture();
    
    // Listen for messages from the extension
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === 'getFormData') {
            sendResponse({ success: true, data: capturedFormData });
        } else if (message.action === 'clearFormData') {
            capturedFormData = [];
            sendResponse({ success: true });
        } else if (message.action === 'autoFillForm') {
            // Store autofilled data for adaptive learning
            if (message.data && Array.isArray(message.data)) {
                autofilledData = [...message.data];
                storeOriginalAutofilledValues(message.data);
            }
            autoFillForm(message.data);
            sendResponse({ success: true });
        } else if (message.action === 'setAdaptiveLearning') {
            isAdaptiveLearningEnabled = message.enabled !== false;
            sendResponse({ success: true });
        }
    });
}

// Store original autofilled values for comparison
function storeOriginalAutofilledValues(data) {
    originalAutofilledValues.clear();
    data.forEach(item => {
        const selector = Object.keys(item).find(k => k !== "type");
        const value = item[selector];
        if (selector && value) {
            originalAutofilledValues.set(selector, value);
        }
    });
}

// Start capturing form data
function startFormCapture() {
    console.log('SabApplier AI: Starting form capture');
    
    // Monitor form elements for changes
    const formElements = document.querySelectorAll('input, select, textarea');
    
    formElements.forEach(element => {
        element.addEventListener('input', handleInputChange);
        element.addEventListener('change', handleInputChange);
        element.addEventListener('blur', handleInputChange);
    });
    
    // Use MutationObserver to detect new form elements
    const observer = new MutationObserver(mutations => {
        mutations.forEach(mutation => {
            mutation.addedNodes.forEach(node => {
                if (node.nodeType === Node.ELEMENT_NODE) {
                    const newFormElements = node.querySelectorAll('input, select, textarea');
                    newFormElements.forEach(element => {
                        element.addEventListener('input', handleInputChange);
                        element.addEventListener('change', handleInputChange);
                        element.addEventListener('blur', handleInputChange);
                    });
                }
            });
        });
    });
    
    observer.observe(document.body, { childList: true, subtree: true });
}

// Handle input changes
function handleInputChange(event) {
    if (!isCapturing) return;
    
    const element = event.target;
    lastInputTime = Date.now();
    
    // Clear previous debounce timer
    if (debounceTimer) {
        clearTimeout(debounceTimer);
    }
    
    // Debounce the capture to avoid excessive updates
    debounceTimer = setTimeout(() => {
        captureFormData();
    }, 500);
}

// Capture form data from the current page
function captureFormData() {
    console.log('SabApplier AI: Capturing form data');
    
    const formData = [];
    const formElements = document.querySelectorAll('input, select, textarea');
    
    formElements.forEach(element => {
        if (element.type === 'hidden' || element.type === 'submit' || element.type === 'button') {
            return;
        }
        
        const selector = generateSelector(element);
        const value = element.value;
        
        if (value && value.trim() !== '') {
            const fieldData = {
                selector: selector,
                value: value,
                type: element.type,
                name: element.name,
                id: element.id,
                placeholder: element.placeholder,
                label: getFieldLabel(element),
                timestamp: Date.now()
            };
            
            formData.push(fieldData);
        }
    });
    
    // Only update if data has changed
    if (JSON.stringify(formData) !== JSON.stringify(capturedFormData)) {
        capturedFormData = formData;
        console.log('SabApplier AI: Form data captured:', formData.length, 'fields');
    }
}

// Generate a unique selector for an element
function generateSelector(element) {
    if (element.id) {
        return `#${element.id}`;
    }
    
    if (element.name) {
        return `[name="${element.name}"]`;
    }
    
    // Create a more specific selector
    let selector = element.tagName.toLowerCase();
    
    if (element.type) {
        selector += `[type="${element.type}"]`;
    }
    
    if (element.className) {
        const classes = element.className.split(' ').filter(c => c.length > 0);
        if (classes.length > 0) {
            selector += '.' + classes.join('.');
        }
    }
    
    return selector;
}

// Get field label
function getFieldLabel(element) {
    // Try to find label by 'for' attribute
    if (element.id) {
        const label = document.querySelector(`label[for="${element.id}"]`);
        if (label) return label.textContent.trim();
    }
    
    // Try to find label by parent
    const parentLabel = element.closest('label');
    if (parentLabel) {
        return parentLabel.textContent.replace(element.value, '').trim();
    }
    
    // Try to find label by proximity
    const prevElement = element.previousElementSibling;
    if (prevElement && prevElement.tagName === 'LABEL') {
        return prevElement.textContent.trim();
    }
    
    return element.placeholder || element.name || '';
}

// Auto-fill form with provided data
function autoFillForm(data) {
    console.log('SabApplier AI: Auto-filling form with data:', data);
    
    if (!data || !Array.isArray(data)) {
        console.error('SabApplier AI: Invalid data provided for auto-fill');
        return;
    }
    
    let filledCount = 0;
    
    data.forEach(item => {
        const selector = Object.keys(item).find(k => k !== "type");
        const value = item[selector];
        
        if (selector && value) {
            const elements = document.querySelectorAll(selector);
            
            elements.forEach(element => {
                if (element.type === 'checkbox' || element.type === 'radio') {
                    element.checked = value === 'true' || value === true;
                } else if (element.tagName === 'SELECT') {
                    // For select elements, try to find the option
                    const option = Array.from(element.options).find(opt => 
                        opt.value === value || opt.text === value
                    );
                    if (option) {
                        element.selectedIndex = option.index;
                    }
                } else {
                    element.value = value;
                }
                
                // Trigger change event
                element.dispatchEvent(new Event('input', { bubbles: true }));
                element.dispatchEvent(new Event('change', { bubbles: true }));
                
                filledCount++;
            });
        }
    });
    
    console.log(`SabApplier AI: Auto-filled ${filledCount} fields`);
}

// Initialize when the content script loads
initialize();
